<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jurusans extends Model
{
    protected $table = "jurusans";
    protected $fillable = ["name"];

}
