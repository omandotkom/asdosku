<!DOCTYPE html>
<html lang="id">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title><?php if(isset($title)): ?> <?php echo e($title); ?> <?php else: ?> Asdosku <?php endif; ?></title>

  <!-- Custom fonts for this template-->
  <link href="<?php echo e(asset('sbadmin/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <!-- Custom styles for this template-->
  <link href="<?php echo e(asset('sbadmin/css/sb-admin-2.min.css')); ?>" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php if(Auth::user()->role == "dosen"): ?>
    <?php echo $__env->make('layouts.dosen.dashboardsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(Auth::user()->role == "operational"): ?>
    <?php echo $__env->make('layouts.operational.dashboardsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(Auth::user()->role == "hrd"): ?>
    <?php echo $__env->make('layouts.hrd.dashboardsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(Auth::user()->role == "asdos"): ?>
    <?php echo $__env->make('layouts.asdos.dashboardsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <!--Sidebar ada di sini -->

    <!-- End of Sidebar -->
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <?php echo $__env->make('layouts.dashboardtopbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--top bar ada di sini -->
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 id="judulHalaman" class="h3 mb-0 text-gray-800"><?php echo e($title); ?></h1>
          </div>
          <?php if(Auth::user()->role == "operational"): ?>
          <?php switch($content ?? ''):
          case ('pendingpayout'): ?>
          <?php echo $__env->make('layouts.operational.pendingpayoutlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php case ('pesananasdoslist'): ?>
          <?php echo $__env->make('layouts.operational.pendinglist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php case ('berjalanlist'): ?>
          <?php echo $__env->make('layouts.operational.berjalanlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php case ('historisbiaya'): ?>
          <?php echo $__env->make('layouts.operational.costhistory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php default: ?>
          <?php echo $__env->make('layouts.operational.row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php endswitch; ?>
          <?php elseif(Auth::user()->role == "dosen"): ?>
          <?php switch($content ?? ''):
          case ('viewpayouts'): ?>
          <?php echo $__env->make('layouts.dosen.transaction.payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php case ('payment'): ?>
          <?php echo $__env->make('layouts.dosen.transaction.payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php case ('viewcomments'): ?>
          <?php echo $__env->make('layouts.asdos.commentrating', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php case ('viewAsdoswithFilter'): ?>
          <?php echo $__env->make('layouts.dosen.rowasdos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php case ('order'): ?>
          <?php echo $__env->make('layouts.dosen.transaction.order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php case ('orderlist'): ?>
          <?php echo $__env->make('layouts.dosen.transaction.orderlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php default: ?>
          <?php echo $__env->make('layouts.dosen.row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php endswitch; ?>
          <?php elseif(Auth::user()->role == "hrd"): ?>
          <?php switch($content ?? ''):
          case ('persetujuanlist'): ?>
          <?php echo $__env->make('layouts.hrd.persetujuan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php default: ?>
          <?php echo $__env->make('layouts.hrd.row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php endswitch; ?>
          <?php elseif(Auth::user()->role == "asdos"): ?>
          <?php switch($content ?? ''):
          case ('profile'): ?>
          <?php echo $__env->make('layouts.asdos.profile2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php case ('berjalanlist'): ?>
          <?php echo $__env->make('layouts.operational.berjalanlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php case ('viewcomments'): ?>
          <?php echo $__env->make('layouts.asdos.commentrating', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php default: ?>
          <?php echo $__env->make('layouts.asdos.row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php break; ?>
          <?php endswitch; ?>
          <?php endif; ?>
        
          <!-- Content Row -->
          
          </div>
      </div>

    </div>
    <!-- End of Main Content -->

    <!-- Footer -->
    <footer class="sticky-footer bg-white">
      <div class="container my-auto">
        <div class="copyright text-center my-auto">
          <span>Copyright &copy; Asdosku 2020</span>
        </div>
      </div>
    </footer>
    <!-- End of Footer -->

  </div>
  <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <?php echo $__env->make('layouts.dashboardlogoutmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo e(asset('sbadmin/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('sbadmin/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?php echo e(asset('sbadmin/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?php echo e(asset('sbadmin/js/sb-admin-2.min.js')); ?>"></script>

  <!-- Page level plugins -->
  <script src="<?php echo e(asset('sbadmin/vendor/chart.js/Chart.min.js')); ?>"></script>

  <!-- Page level custom scripts -->
  <script src="<?php echo e(asset('sbadmin/js/demo/chart-area-demo.js')); ?>"></script>
  <script src="<?php echo e(asset('sbadmin/js/demo/chart-pie-demo.js')); ?>"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\asdosku\resources\views/maindashboard/index.blade.php ENDPATH**/ ?>