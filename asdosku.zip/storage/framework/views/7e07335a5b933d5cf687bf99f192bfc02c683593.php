<?php
function convertRupiah($val){
return number_format($val,2,',','.');
}
$totalbiaya = 0;
?>


<div class="container">
  <div class="row">

    <div class="card shadow p-3 mb-5 bg-white rounded">

      <div class="card-body">
        <h5 class="card-title text-center">Pembayaran</h5>

        <div class="text-center">
          <img src="<?php echo e(asset('asset/img/logo.png')); ?>" class="img-thumbnail p-3 mb-5 bg-white rounded" alt="Foto Asdos">
        </div>
        <div class="table-responsive-xl mt-1">
          <table class="table table-sm table-bordered">
            <thead>
              <tr class="table-warning">

                <th scope="col">No</th>
                <th scope="col">Keterangan</th>
                <th scope="col">Biaya (Rp)</th>
                <th scope="col">Tanggal</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $num =1;
              $totalbiaya = $totalbiaya + $transaction->biaya;
              ?>
              <tr>
                <td><?php echo e($num); ?></td>
                <td>(Layanan) <?php echo e($transaction->activity->name); ?></td>
                <td><?php echo convertRupiah($transaction->biaya); ?> </td>
                <td><?php echo e($transaction->created_at); ?></td>

              </tr>
              <?php $__currentLoopData = $costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
              $totalbiaya = $totalbiaya + $cost->nominal;
              $num++;
              ?>
              <tr>
                <td><?php echo e($num); ?></td>
                <td><?php echo e($cost->keterangan); ?></td>
                <td><?php echo convertRupiah($cost->nominal); ?></td>
                <td><?php echo e($cost->updated_at); ?></td>

              </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td colspan="2"><b>Total Biaya</b></td>

                <td colspan="2"><?php echo "Rp. ".convertRupiah($totalbiaya); ?></td>


              </tr>
            </tbody>
          </table>
        </div>

        <form name="paymentform" enctype="multipart/form-data" method="POST" action="<?php echo e(route('storepayout',$transaction->id)); ?>">
          <input type="hidden" name="total" value="<?php echo e($totalbiaya); ?>">
          <div class="form-group">
            <?php echo csrf_field(); ?>
            <label for="pembayaran">Bukti Pembayaran</label>
            <input required type="file" accept="image/*" name="pembayaran" class="form-control <?php $__errorArgs = ['pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Bukti pembayaraan" id="pembayaran">
            <?php $__errorArgs = ['pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <h5 class="card-title text-center mt-3">Nilai Asdos Kami</h5>

          <div class="form-group">
            <label for="rating">Nilai untuk Asdos</label>
            <input required type="number" min="1" max="5" class="form-control <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="rating" aria-describedby="ratingHelp" name="rating">
            <small id="ratingHelp" class="form-text text-muted">Dalam skala 1 sampai 5</small>
            <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label for="komentar">Komentar untuk Asdos</label>
            <textarea required placeholder="mis : Asisten cukup responsif" name="komentar" class="form-control <?php $__errorArgs = ['komentar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="komentar" rows="5"></textarea>
            <?php $__errorArgs = ['komentar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <input type="hidden" name="transaction_id">

          <h5 class="card-title text-center mt-1">Metode Pembayaran</h5>
          <table class="table table-sm table-responsive-sm table-borderless">
            <thead>
              <tr>
                <th scope="col" style="width: 64px;">Via</th>
                <th scope="col">Keterangan</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><img class="img-thumbnail" src="<?php echo e(asset('asset/img/payment/dana.PNG')); ?>" alt="DANA App"></td>
                <td><b>081393558430</b> a.n <b>Khalid Abdurrahman</b></td>
              </tr>
              <tr>
                <td><img class="img-thumbnail" src="<?php echo e(asset('asset/img/payment/bca.PNG')); ?>" alt="BCA"></td>
                <td>a.n DNID 081393558430<br>Virtual Account : <b>3901081393558430</b></td>
              </tr>
              <tr>
                <td><img class="img-thumbnail" src="<?php echo e(asset('asset/img/payment/bni.PNG')); ?>" alt="BNI"></td>
                <td>a.n DNID 081393558430<br>Virtual Account : <b>8810081393558430</b></td>
              </tr>
              <tr>
                <td><img class="img-thumbnail" src="<?php echo e(asset('asset/img/payment/mandiri.PNG')); ?>" alt="MANDIRI"></td>
                <td>a.n DNID 081393558430<br>Virtual Account : <b>89508081393558430</b></td>
              </tr>
              <tr>
                <td><img class="img-thumbnail" src="<?php echo e(asset('asset/img/payment/btn.PNG')); ?>" alt="BTN"></td>
                <td>a.n DNID 081393558430<br>Virtual Account : <b>8528081393558430</b></td>
              </tr>
            </tbody>
          </table>
        <h5 class="card-title text-center mt-1">Cara Membayar</h5>
          <ol>
            <li>Pilih salah satu metode pembayaran yang tertera di atas.</li>
            <li>Nominal yang harus di transfer adalah <b>Rp. <?php echo e($totalbiaya); ?>.</b></li>
            <li>Pastikan nominal yang ditransfer tepat.</li>
            <li>Screenshoot (jika dengan m-banking) atau foto bukti pembayaran (jika dari atm).</li>
            <li>Unggah bukti pembayaran di kolom <b>Bukti Pembayaran</b>
          </ol>
          <button onclick="document.paymentform.submit();" class="btn btn-primary btn-lg btn-block">Unggah Bukti Pembayaran dan Penilaian</button>
      </div>
      </form>
    </div>
  </div>
</div>




</div>
</div><?php /**PATH C:\xampp\htdocs\asdosku\resources\views/layouts/dosen/transaction/payment.blade.php ENDPATH**/ ?>