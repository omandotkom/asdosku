<?php $__env->startSection('title', sprintf('%s — %s', config('app.name'), __('canvas::blog.title'))); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('blog.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if($data['topics']): ?>
            <div class="nav-scroller py-1 mb-2">
                <nav class="nav d-flex justify-content-between">
                    <?php $__currentLoopData = $data['topics']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="p-2 text-muted text-decoration-none" href="<?php echo e(route('blog.topic', $topic->slug)); ?>"><?php echo e($topic->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </nav>
            </div>
        <?php endif; ?>

        <?php if($data['posts']->count() > 0): ?>
            <?php $__currentLoopData = $data['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->first): ?>
                    <div class="jumbotron p-4 p-md-5 text-white rounded <?php if(empty($post->featured_image)): ?> bg-dark <?php endif; ?>"
                         <?php if(!empty($post->featured_image)): ?> style="background: linear-gradient(rgba(0, 0, 0, 0.85),rgba(0, 0, 0, 0.85)),url(<?php echo e($post->featured_image); ?>); background-size: cover" <?php endif; ?>>
                        <div class="col-md-8 px-0">
                            <h1 class="font-italic font-serif">
                                <a href="<?php echo e(route('blog.post', $post->slug)); ?>" class="text-white text-decoration-none"><?php echo e($post->title); ?></a>
                            </h1>
                            <p class="lead my-3">
                                <a href="<?php echo e(route('blog.post', $post->slug)); ?>" class="text-white text-decoration-none"><?php echo e($post->summary); ?></a>
                            </p>
                            <p class="lead mb-0">
                                <a href="<?php echo e(route('blog.post', $post->slug)); ?>" class="text-white font-weight-bold text-decoration-none"><?php echo e(__('canvas::blog.buttons.continue')); ?></a>
                            </p>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

    <main role="main" class="container <?php if($data['posts']->count() == 0): ?> mt-4 <?php endif; ?>">
        <div class="row">
            <div class="col-md-8">
                <h3 class="mb-4 font-italic <?php if($data['posts']->count() > 0): ?> pb-4 border-bottom <?php endif; ?> font-serif">
                    <?php echo e(__('canvas::blog.posts.label')); ?>

                </h3>
                <?php if($data['posts']->count() > 0): ?>
                    <?php $__currentLoopData = $data['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$loop->first): ?>
                            <div class="mb-5">
                                <h3>
                                    <a href="<?php echo e(route('blog.post', $post->slug)); ?>" class="font-serif text-dark text-decoration-none"><?php echo e($post->title); ?></a>
                                </h3>
                                <p class="text-muted mb-2"><?php echo e($post->published_at->formatLocalized('%b %d')); ?> — <?php echo e($post->read_time); ?></p>
                                <p>
                                    <a href="<?php echo e(route('blog.post', $post->slug)); ?>" class="text-dark text-decoration-none"><?php echo e($post->summary); ?></a>
                                </p>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php echo e($data['posts']->links()); ?>

                <?php else: ?>
                    <p class="mt-4"><?php echo e(__('canvas::blog.empty.description')); ?>

                        <a href="<?php echo e(url(sprintf('%s/posts/create', config('canvas.path')))); ?>" class="text-success text-decoration-none"><?php echo e(__('canvas::blog.empty.action')); ?></a>.
                    </p>
                <?php endif; ?>
            </div>

            <?php if($data['tags']): ?>
                <aside class="col-md-4">
                    <div class="p-md-4">
                        <h4 class="font-italic font-serif"><?php echo e(__('canvas::blog.tags.label')); ?></h4>
                        <ol class="list-unstyled mb-0">
                            <?php $__currentLoopData = $data['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('blog.tag', $tag->slug)); ?>" class="text-decoration-none text-secondary"><?php echo e($tag->name); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                    </div>
                </aside>
            <?php endif; ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('blog.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asdosku\resources\views/blog/index.blade.php ENDPATH**/ ?>