<div class="row">
<a href="<?php echo e(URL::previous()); ?>" class="badge badge-secondary">Kembali</a>
</div>
<div class="row">
  Rating : <?php if(isset($rating)): ?> <?php echo e($rating->rating); ?> / 5 dari <?php echo e($rating->person); ?> asistensi <?php else: ?> - <?php endif; ?>
</div>
<div class="row mt-3">

  <ul class="list-group">
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item">
      <blockquote class="blockquote">
        <p class="mb-0"><?php echo e($comment->comment); ?></p>
        <footer class="blockquote-footer"><cite title="Source Title"><?php echo e($comment->created_at); ?></cite></footer>
      </blockquote>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul> <?php echo e($comments->links()); ?>

</div>
</div><?php /**PATH C:\xampp\htdocs\asdosku\resources\views/layouts/asdos/commentrating.blade.php ENDPATH**/ ?>