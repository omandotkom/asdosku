<!-- Modal -->
<script>
    function generatePenelitianURL(){
        var penelitianURL = "<?php echo e(route('viewgeneral')); ?>";
        penelitianURL = penelitianURL.concat("/").concat($("#penelitianactivity").val());
        window.location = penelitianURL;
    }
</script>
<div class="modal fade" id="penelitianModal" tabindex="-1" role="dialog" aria-labelledby="titlePenelitian" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="titlePenelitian">Filter Asisten Penelitian</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">

                        <label for="penelitianactivity" class="col-form-label float-left">Jenis Kegiatan</label>
                        <select name="activity" id="penelitianactivity" required class="custom-select custom-select-sm">
                        <?php $__currentLoopData = $penelitianactivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($p->first): ?>
                            <option selected value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                            <?php endif; ?>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
              </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                <button type="button" onclick="generatePenelitianURL();" class="btn btn-primary">Lanjutkan</button>
                </script>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\asdosku\resources\views/layouts/dosen/dashboardmodal/penelitianModal.blade.php ENDPATH**/ ?>