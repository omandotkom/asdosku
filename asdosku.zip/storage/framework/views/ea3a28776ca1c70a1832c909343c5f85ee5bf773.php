<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<?php if(empty($prefer)): ?>
<script type="text/javascript">
  Toastify({
    backgroundColor: "linear-gradient(to right, #ff416c, #ff4b2b)",
    text: "Pilih satu atau beberapa kegiatan.",

    duration: 10000

  }).showToast();
</script>
<?php endif; ?>
<?php
  $path = basename($imageurl);
  $picname = basename($path, ".png");
?>
<?php if($picname == "default"): ?>
<script type="text/javascript">
  Toastify({
    backgroundColor: "linear-gradient(to right, #ff416c, #ff4b2b)",
    text: "Anda belum mengunggah foto profile.",

    duration: 10000

  }).showToast();
</script>
<?php endif; ?>
<div class="container">
  <div class="row">
    <div class="col-sm-6">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Informasi Layanan</h5>
          <p class="card-text">Pilih satu atau beberapa pekerjaan dibawah dengan mencentang yang kamu inginkan. Hal ini digunakan agar ketika dosen sedang mencari asisten, akunmu ikut ditampilkan.</p>
          <?php if(session('successprefer')): ?>
          <div class="alert alert-success">
            <?php echo e(session('successprefer')); ?>

          </div>
          <?php endif; ?>
          <form action="<?php echo e(route('updatePreferAsdos')); ?>" method="post">
            <?php echo csrf_field(); ?>

            <div class="container pl-auto">
              <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="row">
                <div class="font-weight-bold">
                  <?php echo e($service->name); ?>

                </div>
              </div>

              <?php $__currentLoopData = $service->activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="form-check">
                <label class="form-check-label">
                  <?php
                  $name = $activity->id."check";

                  ?>
                  <input type="checkbox" <?php if(in_array($name,$prefer)): ?> checked <?php endif; ?> name="<?php echo e($activity->id); ?>check" class="form-check-input" value="<?php echo e($activity->id); ?>"><?php echo e($activity->name); ?>

                </label>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="form-group mt-3">
              <button type="submit" class="btn btn-danger btn-sm">Upload</button>
            </div>

          </form>





        </div>
      </div>
    </div>
    <div class="col-sm-6">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Foto Profile</h5>
          <div class="text-center">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
              <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <img src="<?php echo e($imageurl); ?>" class="rounded" alt="...">

            <form class="mt-3" id="profilePic" name="profilePic" method="post" action="<?php echo e(route('uploadProfileAsdos')); ?>" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="custom-file">
                <input type="file" class="custom-file-input" name="image" id="customFile">
                <label class="custom-file-label" for="customFile">Choose file</label>
              </div>
              <div class="form-group mt-3">
                <button class="btn btn-danger btn-sm">Upload</button>
              </div>
            </form>


            <!--<button type="button" class="btn mt-3 btn-success btn-sm btn-block">Unggah Foto</button> -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div><?php /**PATH C:\xampp\htdocs\asdosku\resources\views/layouts/asdos/profile2.blade.php ENDPATH**/ ?>