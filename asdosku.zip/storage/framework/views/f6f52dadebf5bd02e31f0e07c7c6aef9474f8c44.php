<!-- Modal -->
<script>
    function generateMatakuliahURL() {
        var matakuliahURL = "<?php echo e(route('viewmatakuliah')); ?>";
        matakuliahURL = matakuliahURL.concat("/").concat($("#activitymatakuliah").val()).concat("/")
            .concat($("#kampusmatakuliah").val()).concat("/").concat($("#jurusanmatakuliah").val()).concat("/")
            .concat($("#semestermatakuliah").val()).concat("/").concat($("#gendermatakuliah").val());
       window.location = matakuliahURL;
    }
</script>
<div class="modal fade" id="makulModal" tabindex="-1" role="dialog" aria-labelledby="titleMakul" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="titleMakul">Filter Asisten Matakuliah</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="mapel" class="col-form-label float-left">Matakuliah</label>

                    <select required id="activitymatakuliah" name="activity" class="custom-select custom-select-sm"> <?php $__currentLoopData = $matakuliahactivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->first): ?>
                        <option selected value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                        <?php else: ?>
                        <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="semester" class="col-form-label float-left">Semester</label>
                    <select name="semester" id="semestermatakuliah" required class="custom-select custom-select-sm">
                        <option selected value="Bebas">Bebas</option>
                        <?php for($i = 1; $i < 10; $i++): ?><option value="<?php echo e($i); ?>"> <?php echo e($i); ?> </option>
                            <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="kampus" class="col-form-label float-left">Asal Kampus</label>
                    <select name="kampus" id="kampusmatakuliah" required class="custom-select custom-select-sm">
                        <option selected value="Bebas">Bebas</option>
                        <?php $__currentLoopData = $campuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($campus->id); ?>"><?php echo e($campus->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="jurusan" class="col-form-label float-left">Jurusan</label>
                    <select name="jurusan" id="jurusanmatakuliah" required class="custom-select custom-select-sm">
                        <option selected value="Bebas">Bebas</option>
                        <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($jurusan->id); ?>"><?php echo e($jurusan->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="gender" class="col-form-label float-left">Gender</label>
                    <select required name="gender" id="gendermatakuliah" class="custom-select custom-select-sm">
                        <option selected value="Bebas">Bebas</option>
                        <option value="Pria">Pria</option>
                        <option value="Wanita">Wanita</option>
                    </select>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                <button type="button" onclick="generateMatakuliahURL();" class="btn btn-primary">Lanjutkan</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\asdosku\resources\views/layouts/dosen/dashboardmodal/makulModal.blade.php ENDPATH**/ ?>