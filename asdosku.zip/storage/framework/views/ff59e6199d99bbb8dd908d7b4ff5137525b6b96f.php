<!-- Modal -->
<script>
    function generatePengabdianURL(){
        var pengabdianURL = "<?php echo e(route('viewgeneral')); ?>";
        pengabdianURL = pengabdianURL.concat("/").concat($("#pengabdianactivity").val());
        window.location = pengabdianURL;
    }
    </script>
<div class="modal fade" id="pengabdianModal" tabindex="-1" role="dialog" aria-labelledby="titlepengabdian" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="titlepengabdian">Filter Asisten Pengabdian</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               
                    <div class="form-group">

                        <label for="pengabdianactivity" class="col-form-label float-left">Jenis Kegiatan</label>
                        <select name="activity" id="pengabdianactivity" required class="custom-select custom-select-sm">
                        <?php $__currentLoopData = $pengabdianactivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($p->first): ?>
                            <option selected value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                            <?php endif; ?>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                <button type="button" onclick="generatePengabdianURL();" class="btn btn-primary">Lanjutkan</button>
                </script>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\asdosku\resources\views/layouts/dosen/dashboardmodal/pengabdianModal.blade.php ENDPATH**/ ?>